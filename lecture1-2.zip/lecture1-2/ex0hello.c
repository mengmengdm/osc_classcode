#include <stdio.h>

int main() {
   /* my first program in C */
   printf("Hello, World! \n");
   return 0;

}
