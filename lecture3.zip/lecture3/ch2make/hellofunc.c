#include <stdio.h>
#include "hellofunc.h"

void myPrintHelloMake(char * who) {

  printf("Hello %s!\n", who);

  return;
}