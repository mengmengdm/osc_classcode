/*
example include file
*/
void myPrintHelloMake(char * who);