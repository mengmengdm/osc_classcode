
#ifndef LECTURE4_FATHER_H
#define LECTURE4_FATHER_H

#include "grandfather.h"

#define TOTAL_SIZE 5 * BUFFER_SIZE
#endif //LECTURE4_FATHER_H
