#ifndef H_MYHEADER
#define H_MYHEADER

#include "father.h"
#include "grandfather.h"

#define MY_SIZE  0.50 * TOTAL_SIZE

#endif //H_MYHEADER