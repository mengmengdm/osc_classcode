strace -e trace=creat,open,openat,close,read,write ./mycp a.out y.out
